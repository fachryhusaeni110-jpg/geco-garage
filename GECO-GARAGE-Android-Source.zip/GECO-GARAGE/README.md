# GECO GARAGE — Android starter project

Native Android app starter using Kotlin + Jetpack Compose + Firebase Authentication + Cloud Firestore.

## Current features
- Email/password registration and login
- User-scoped cloud data in Firestore
- Dashboard counters
- Add and view service records
- Add and view replacement-part records
- Sign out

## Required Firebase setup (one-time)
1. Create a Firebase project in the Firebase Console.
2. Add an Android app with package name `com.gecogarage.app`.
3. Download `google-services.json` and place it in `app/google-services.json`.
4. Enable Authentication > Email/Password.
5. Create a Cloud Firestore database.
6. Publish the rules in `firestore.rules`.
7. Open this folder in Android Studio and let Gradle sync.

## Build APK
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Or from a machine with Android SDK and Gradle available: `gradle assembleDebug`.

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This project is a starter build, not a compiled APK. An Android SDK/Gradle build environment and your Firebase project configuration are required to produce a working installable APK with cloud sync.
- Data is stored under `users/{Firebase UID}/serviceRecords` and `users/{Firebase UID}/parts`.
- Never publish permissive Firestore rules. The included rules restrict each account to its own records.
