package com.gecogarage.app.data

data class ServiceRecord(
    val id: String = "",
    val date: String = "",
    val odometer: Long = 0,
    val category: String = "Servis umum",
    val title: String = "",
    val notes: String = "",
    val cost: Long = 0,
    val nextDue: String = ""
)

data class PartRecord(
    val id: String = "",
    val date: String = "",
    val partName: String = "",
    val brand: String = "",
    val odometer: Long = 0,
    val cost: Long = 0,
    val notes: String = ""
)
