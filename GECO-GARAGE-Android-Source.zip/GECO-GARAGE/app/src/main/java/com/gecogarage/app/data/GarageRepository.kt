package com.gecogarage.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class GarageRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun register(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password).await()
    }
    suspend fun login(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }
    fun logout() = auth.signOut()
    fun currentUserId(): String? = auth.currentUser?.uid

    private fun records() = db.collection("users").document(requireNotNull(currentUserId())).collection("serviceRecords")
    private fun parts() = db.collection("users").document(requireNotNull(currentUserId())).collection("parts")

    suspend fun addService(record: ServiceRecord) {
        val ref = records().document()
        ref.set(record.copy(id = ref.id)).await()
    }
    suspend fun addPart(record: PartRecord) {
        val ref = parts().document()
        ref.set(record.copy(id = ref.id)).await()
    }
    suspend fun getServices(): List<ServiceRecord> = records().get().await().toObjects(ServiceRecord::class.java).sortedByDescending { it.date }
    suspend fun getParts(): List<PartRecord> = parts().get().await().toObjects(PartRecord::class.java).sortedByDescending { it.date }
    suspend fun deleteService(id: String) { records().document(id).delete().await() }
    suspend fun deletePart(id: String) { parts().document(id).delete().await() }
}
