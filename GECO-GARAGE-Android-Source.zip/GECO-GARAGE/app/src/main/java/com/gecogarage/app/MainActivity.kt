package com.gecogarage.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gecogarage.app.data.GarageRepository
import com.gecogarage.app.data.ServiceRecord
import com.gecogarage.app.data.PartRecord
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF202522)
private val Cream = Color(0xFFF5F2EB)
private val Gold = Color(0xFFC9A45C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Ink, secondary = Gold, background = Cream, surface = Color.White)) { GarageApp() } }
    }
}

@Composable
fun GarageApp() {
    val repo = remember { GarageRepository() }
    var user by remember { mutableStateOf(repo.currentUserId()) }
    var tab by remember { mutableStateOf("Dashboard") }
    var services by remember { mutableStateOf<List<ServiceRecord>>(emptyList()) }
    var parts by remember { mutableStateOf<List<PartRecord>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    fun refresh() { scope.launch { try { busy = true; services = repo.getServices(); parts = repo.getParts(); error = "" } catch (e: Exception) { error = e.message ?: "Gagal memuat data" } finally { busy = false } } }
    LaunchedEffect(user) { if (user != null) refresh() }

    if (user == null) {
        AuthScreen(error, busy, onLogin = { email, pass -> scope.launch { try { busy = true; repo.login(email, pass); user = repo.currentUserId() } catch (e: Exception) { error = e.message ?: "Login gagal" } finally { busy = false } } }, onRegister = { email, pass -> scope.launch { try { busy = true; repo.register(email, pass); user = repo.currentUserId() } catch (e: Exception) { error = e.message ?: "Registrasi gagal" } finally { busy = false } } })
    } else {
        Scaffold(containerColor = Cream, topBar = {
            Row(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("GECO GARAGE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp); Text("YOUR CAR. YOUR HISTORY.", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp) }
                IconButton(onClick = { repo.logout(); user = null }) { Icon(Icons.Default.Logout, null, tint = Color.White) }
            }
        }, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Dashboard", "Servis", "Part").forEach { label -> NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(when(label) { "Dashboard" -> Icons.Default.DirectionsCar; "Servis" -> Icons.Default.History; else -> Icons.Default.Settings }, null) }, label = { Text(label) }) }
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
                when (tab) {
                    "Dashboard" -> Dashboard(services, parts, busy, onRefresh = { refresh() }, onAddService = { tab = "TambahServis" }, onAddPart = { tab = "TambahPart" })
                    "Servis" -> RecordList("Riwayat Servis", services.map { "${it.date} · ${it.title}" to "${it.category}  •  ${rupiah(it.cost)}" }, onAdd = { tab = "TambahServis" })
                    "Part" -> RecordList("Pergantian Part", parts.map { "${it.date} · ${it.partName}" to "${it.brand}  •  ${rupiah(it.cost)}" }, onAdd = { tab = "TambahPart" })
                    "TambahServis" -> AddServiceScreen(onCancel = { tab = "Servis" }, onSave = { item -> scope.launch { try { repo.addService(item); refresh(); tab = "Servis" } catch (e: Exception) { error = e.message ?: "Gagal menyimpan" } } })
                    "TambahPart" -> AddPartScreen(onCancel = { tab = "Part" }, onSave = { item -> scope.launch { try { repo.addPart(item); refresh(); tab = "Part" } catch (e: Exception) { error = e.message ?: "Gagal menyimpan" } } })
                }
            }
        }
    }
}

@Composable
fun AuthScreen(error: String, busy: Boolean, onLogin: (String, String) -> Unit, onRegister: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Ink).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GECO", color = Gold, fontSize = 14.sp, letterSpacing = 5.sp)
        Text("GARAGE", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
        Text("Digital service book for your Corolla", color = Color.LightGray)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onLogin(email.trim(), pass) }, enabled = !busy && email.isNotBlank() && pass.length >= 6, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Memproses..." else "Login") }
        TextButton(onClick = { onRegister(email.trim(), pass) }, enabled = !busy && email.isNotBlank() && pass.length >= 6, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Buat akun baru", color = Gold) }
    }
}

@Composable
fun Dashboard(services: List<ServiceRecord>, parts: List<PartRecord>, busy: Boolean, onRefresh: () -> Unit, onAddService: () -> Unit, onAddPart: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(22.dp)).padding(20.dp)) {
                Text("GARAGE OVERVIEW", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("TOYOTA GREAT COROLLA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("GECO  •  DIGITAL MAINTENANCE LOG", color = Color.LightGray, fontSize = 10.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("${services.size}", "TOTAL SERVIS", Modifier.weight(1f))
                    StatCard("${parts.size}", "PART TERGANTI", Modifier.weight(1f))
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = onAddService, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Text("Catat Servis") }; OutlinedButton(onClick = onAddPart, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Text("Catat Part") } } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Aktivitas Terakhir", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f)); TextButton(onClick = onRefresh) { Text("Refresh") } } }
        if (busy) item { CircularProgressIndicator() }
        items(services.take(5)) { r -> RecordCard(r.date, r.title, "${r.category} • ${rupiah(r.cost)}") }
        items(parts.take(5)) { r -> RecordCard(r.date, r.partName, "${r.brand} • ${rupiah(r.cost)}") }
        if (services.isEmpty() && parts.isEmpty() && !busy) item { Text("Belum ada catatan. Yuk mulai isi riwayat GECO!", color = Color.Gray) }
    }
}

@Composable fun StatCard(value: String, label: String, modifier: Modifier = Modifier) { Column(modifier.background(Color(0xFF343B36), RoundedCornerShape(14.dp)).padding(14.dp)) { Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text(label, color = Gold, fontSize = 9.sp, letterSpacing = 1.sp) } }
@Composable fun RecordList(title: String, rows: List<Pair<String,String>>, onAdd: () -> Unit) { Column(Modifier.fillMaxSize().padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); FilledTonalButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("Tambah") } }; Spacer(Modifier.height(12.dp)); if (rows.isEmpty()) Text("Belum ada data.", color = Color.Gray) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(rows) { RecordCard(it.first, it.second, "") } } } }
@Composable fun RecordCard(title: String, subtitle: String, extra: String) { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(title, fontWeight = FontWeight.Bold); if (subtitle.isNotBlank()) Text(subtitle, color = Color.DarkGray); if (extra.isNotBlank()) Text(extra, color = Gold, fontSize = 12.sp) } } }

@Composable fun AddServiceScreen(onCancel: () -> Unit, onSave: (ServiceRecord) -> Unit) {
    var date by remember { mutableStateOf("2026-11-23") }; var odo by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Servis umum") }; var title by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("0") }; var next by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) { Text("Catat Servis", fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); FormField("Tanggal (YYYY-MM-DD)", date) { date = it }; FormField("Kilometer", odo) { odo = it }; FormField("Kategori", category) { category = it }; FormField("Pekerjaan", title) { title = it }; FormField("Biaya (rupiah)", cost) { cost = it }; FormField("Servis berikutnya", next) { next = it }; FormField("Catatan", notes) { notes = it }; Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Batal") }; Button(onClick = { onSave(ServiceRecord(date = date, odometer = odo.toLongOrNull() ?: 0, category = category, title = title, notes = notes, cost = cost.toLongOrNull() ?: 0, nextDue = next)) }, enabled = title.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Simpan") } } }
}
@Composable fun AddPartScreen(onCancel: () -> Unit, onSave: (PartRecord) -> Unit) {
    var date by remember { mutableStateOf("2026-11-23") }; var name by remember { mutableStateOf("") }; var brand by remember { mutableStateOf("") }; var odo by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("0") }; var notes by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) { Text("Catat Pergantian Part", fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); FormField("Tanggal (YYYY-MM-DD)", date) { date = it }; FormField("Nama part", name) { name = it }; FormField("Merek / tipe", brand) { brand = it }; FormField("Kilometer", odo) { odo = it }; FormField("Biaya (rupiah)", cost) { cost = it }; FormField("Catatan", notes) { notes = it }; Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Batal") }; Button(onClick = { onSave(PartRecord(date = date, partName = name, brand = brand, odometer = odo.toLongOrNull() ?: 0, cost = cost.toLongOrNull() ?: 0, notes = notes)) }, enabled = name.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Simpan") } } }
}
@Composable fun FormField(label: String, value: String, onChange: (String) -> Unit) { OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), singleLine = true) }
fun rupiah(value: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value).replace(",00", "")
